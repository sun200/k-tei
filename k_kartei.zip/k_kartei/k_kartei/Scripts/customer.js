﻿$(document).ready(function(){

    $("#c_add").click(function () {
       
        var customer = new Object();

        customer.name = $('#c_lastname').val();
        customer.vorname = $('#c_firstname').val();
        customer.adresse = $('#c_adresse').val();
        customer.birth = $('#c_birthDay').val();
       
        if (customer != null) {

            $.ajax({
                type: "POST",
                url: "/Customer/AddForm",
                data: JSON.stringify(customer),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response != null) {
                        alert("Name : " + response.name + ", vorname : " + response.vorname + ", Adresse :" + response.adrese + "  ,BirthDay :" + response.birth);
                    } else {
                        alert(" Opreration unsuccefull");
                    }
                },
                failure: function (response) {
                    alert(response.responseText);
                },
                error: function (response) {
                    alert(response.responseText);
                }
            });  
        }

       
    });

    $('#cu_list').click(function () {
        var url = "/Customer/cuList";
        $.get(url, null, function (data) {
            alert(data);
        });
});