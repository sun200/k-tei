﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using NHibernate;
using NHibernate.Cfg;

namespace k_kartei.nhibernate
{
    public class Nsession
    {
        public static ISession OpenSession()
        {
            var configuration = new Configuration();
            var cPath = HttpContext.Current.Server.MapPath(@"~\Models\hibernate.cfg.xml");
            configuration.Configure(cPath);
            var cf = HttpContext.Current.Server.MapPath(@"~\Mappings\Customer.hbm.xml");
            configuration.AddFile(cf);
            ISessionFactory sessionFactory = configuration.BuildSessionFactory();
            return sessionFactory.OpenSession();



        }

    }
}
