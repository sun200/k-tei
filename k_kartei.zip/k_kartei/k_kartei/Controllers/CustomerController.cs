﻿using k_kartei.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NHibernate;
using NHibernate.Cfg;


namespace k_kartei.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {


            return View();

        }

        public ActionResult Add()
        {

            return View();

        }



        [HttpPost]
        public ActionResult AddForm(Customer customerData)
        {


            Customer cu = new Customer();

            cu.name = customerData.name;
            cu.vorname = customerData.vorname;
            cu.adresse = customerData.adresse;
            cu.birth = customerData.birth;

            using (ISession session = nhibernate.Nsession.OpenSession())
            {
                session.Save(cu);

            }
            return Json(cu, JsonRequestBehavior.AllowGet);
        }

        public ActionResult cuList()
        {

            ViewBag.Message = "Customer List.";
            List<Customer> cu;

            using (ISession session = nhibernate.Nsession.OpenSession())
            {
                cu = session.Query<Customer>().ToList();
            }

            ViewBag.TotalStudents = cu.Count();

            return View(cu);
        }

        public ActionResult Download()
        {

            return View();
        }
    }
}