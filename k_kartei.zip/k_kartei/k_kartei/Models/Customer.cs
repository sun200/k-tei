﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace k_kartei.Models
{
    public class Customer
{
    

        public virtual String name
        {
            get;

            set;
            
        }

        public virtual  String adresse
        {
            get;

            set;
        }

        public virtual  String birth
        {
            get;

            set;
            
        }

        public virtual  String vorname
        {
            get;

            set;
           
        }

        public virtual Int64 id
        {
            get;

            set;

        }

    }
}
