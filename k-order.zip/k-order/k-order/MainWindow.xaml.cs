﻿using k_order.item;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace k_order
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            initOrderList();
            initItemList();
        }

        private void addOrder_Click(object sender, RoutedEventArgs e)
        {
            Random rm = new Random();
            Int32 order_id = rm.Next(1, 500);
            IOrder io = new order.OrderIplm();
            Order order = new Order();
            order.description = orderDescription.Text;
            order.reference = refCustomer.Text;
            order.id = order_id;
            order.titel = orderName.Text;

            MessageBox.Show($"Order ID :{order.id} ; Order Description : { order.description} ; Customer ID: {order.reference} ; Order Titel: { order.titel}");


            io.addOrder(order);
            showOrder.Items.Clear();

            initOrderList();




        }


        private void addItem_Click(object sender, RoutedEventArgs e)
        {
            Random rm = new Random();
            Int32 item_id = rm.Next(500, 1000);
            Iitem it = new ItemIplm();
            Item item = new Item();
            item.description = orderDescription.Text;
            item.reference = refCustomer.Text;
            item.id = item_id;
            item.titel = orderName.Text;

            MessageBox.Show($"item ID :{item.id} ; item Description : { item.description} ; item reference: {item.reference} ; item Titel: { item.titel}");


            it.addItem(item);
            viewItem.Items.Clear();

            initItemList();

        }

        private void addJob_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Job");
        }

        private void showOrder_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            refItem.Text=showOrder.SelectedItem.ToString();
            MessageBox.Show(showOrder.SelectedItem.ToString());
        }

        private void viewItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void viewJob_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        public void initOrderList()
        {
            string[] lines = System.IO.File.ReadAllLines(@"/order/order.txt");

            foreach (string str in lines)
            {
                if(str.Contains(';'))
                showOrder.Items.Add(str.Split(';')[3].Split(':')[1]);
            }
        }

        public void initItemList()
        {
            string[] lines = System.IO.File.ReadAllLines(@"/job/job.txt");

            foreach (string str in lines)
            {
                if (str.Contains(';'))
                    viewItem.Items.Add(str.Split(';')[3].Split(':')[1]);
            }
        }


    }
}
