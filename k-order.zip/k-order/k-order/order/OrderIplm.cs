﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.order
{
    class OrderIplm : IOrder
    {
        public Int32 addOrder(Order order)
        {
           
            using (System.IO.StreamWriter sw = System.IO.File.AppendText(@"/order/order.txt"))
            {
                sw.WriteLine($"Order ID :{order.id} ; Order Description : { order.description} ; Customer ID: {order.reference} ; Order Titel: { order.titel}");
            }

            return order.id;
        }

        public Boolean delteOrder(Int32 id)
        {
            Boolean status = false;
            var lines = System.IO.File.ReadAllLines(@"/order/order.txt").Where(line => Convert.ToInt32(line) != id).ToArray();
            
            System.IO.File.Delete(@"/order/order.txt");
            System.IO.StreamWriter sw = new System.IO.StreamWriter(@"/order/order.txt");
            if (System.IO.File.Exists(@"/order/order.txt"))
            {
                System.IO.File.WriteAllLines(@"/order/order.txt", lines);
                status = true;
            }

            return status;

        }

        public List<Order> orderList()
        {
            string[] lines = System.IO.File.ReadAllLines(@"/order/order.txt");
            List<Order> orderList = new List<Order>();
            Order order = new Order();
            foreach (string str in lines)
            {
                if (str.Contains(';'))
                    order.description = str.Split(';')[1].Split(':')[1];
                order.titel = str.Split(';')[3].Split(':')[1];
                order.reference = str.Split(';')[2].Split(':')[1];
                orderList.Add(order);
            }

            return orderList;
        }

        public void updateOrder(Order order)
        {
            throw new NotImplementedException();
        }
    }
}
