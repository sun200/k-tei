﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order
{
    interface IOrder
    {
        Int32 addOrder(Order order);
        Boolean delteOrder(Int32 id);
        void updateOrder(Order order);
        List<Order> orderList();
    }
}
