﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.item
{
    class ItemIplm:Iitem
    {

        Int32 Iitem.addItem(Item it)
        {
            using (System.IO.StreamWriter sw = System.IO.File.AppendText(@"/job/job.txt"))
            {
                sw.WriteLine($"Item ID :{it.id} ;Item Description : { it.description} ; Item ID: {it.reference} ; Item Titel: { it.titel}");
            }

            return it.id;
        }


        public Boolean delteItem(int id)
        {
            Boolean status = false;
            var lines = System.IO.File.ReadAllLines(@"/job/job.txt").Where(line => Convert.ToInt32(line) != id).ToArray();

            System.IO.File.Delete(@"/job/job.txt");
            System.IO.StreamWriter sw = new System.IO.StreamWriter(@"/job/job.txt");
            if (System.IO.File.Exists(@"/job/job.txt"))
            {
                System.IO.File.WriteAllLines(@"/job/job.txt", lines);
                status = true;
            }

            return status;
        }

        public List<Item> itemList()
        {
            string[] lines = System.IO.File.ReadAllLines(@"/order/order.txt");
            List<Item> itemList = new List<Item>();
            Item item = new Item();
            foreach (string str in lines)
            {
                if (str.Contains(';'))
                    item.description = str.Split(';')[1].Split(':')[1];
                item.titel = str.Split(';')[3].Split(':')[1];
                item.reference = str.Split(';')[2].Split(':')[1];
                itemList.Add(item);
            }

            return itemList;
        }

        public void updateItem(Item it)
        {
            throw new NotImplementedException();
        }

       
        
    }
}
