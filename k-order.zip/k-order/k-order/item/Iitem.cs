﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.item
{
    interface Iitem
    {
         Int32 addItem(Item it);
        Boolean delteItem(Int32 id);
        void updateItem(Item it);
        List<Item> itemList();
    }
}
