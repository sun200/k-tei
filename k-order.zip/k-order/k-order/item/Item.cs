﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.item
{
    class Item
    {
        private String descriptionField;
        private String titleField;
        private Int32 idField;
        private String referenceField;

        public String description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;

            }
        }

        public String titel
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;

            }
        }

        public Int32 id
        {
            get
            {
                return this.idField;

            }
            set
            {
                this.idField = value;

            }
        }

        public String reference
        {
            get
            {
                return this.referenceField;
            }
            set
            {
                this.referenceField = value;

            }
        }


    }
}
