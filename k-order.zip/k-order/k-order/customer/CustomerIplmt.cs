﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.customer
{
    class CustomerIplmt : ICustomer
    {
        public int addCustomer(Customer ct)
        {
            throw new NotImplementedException();
        }

        public List<Customer> CustomerList()
        {
            throw new NotImplementedException();
        }

        public void delteCustomer(int id)
        {
            throw new NotImplementedException();
        }

        public void updateCustomer(Customer it)
        {
            throw new NotImplementedException();
        }
    }
}
