﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.customer
{
    class Customer
    {
        private String nameField;
        private String vornameField;
        private Int32 idField;
        private String adresseField;

        public String name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;

            }
        }

        public String vorname
        {
            get
            {
                return this.vornameField;
            }
            set
            {
                this.vornameField = value;

            }
        }

        public Int32 id
        {
            get
            {
                return this.idField;

            }
            set
            {
                this.idField = value;

            }
        }

        public String adresse
        {
            get
            {
                return this.adresseField;
            }
            set
            {
                this.adresseField = value;

            }
        }

    }
}
