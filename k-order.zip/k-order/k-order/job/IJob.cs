﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.job
{
    interface IJob
    {
        Int32 addJob(Job job);
        void deleteJob(Int32 id);
        void updateJob(Job job);
        List<Job> JobList();

    }
}
