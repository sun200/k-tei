﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace k_order.job
{
    class JobIplm : IJob
    {
        public int addJob(Job job)
        {
            throw new NotImplementedException();
        }

        public void deleteJob(int id)
        {
            throw new NotImplementedException();
        }

        public List<Job> JobList()
        {
            throw new NotImplementedException();
        }

        public void updateJob(Job job)
        {
            throw new NotImplementedException();
        }
    }
}
